import { CheckCircle2, XCircle } from 'lucide-react';
import { AvailabilityResult } from '@/lib/availability';

export function ResultBanner({ result }: { result: AvailabilityResult }) {
  if (result.available) {
    return (
      <div className="flex items-start gap-3 rounded-xl border-2 border-emerald-200 bg-emerald-50 p-4 animate-[fadeIn_0.3s_ease]">
        <CheckCircle2 className="mt-0.5 shrink-0 text-emerald-600" size={24} />
        <div>
          <p className="font-semibold text-emerald-800">Available</p>
          <p className="text-sm text-emerald-700">
            This time slot is open. You can proceed with the booking.
          </p>
        </div>
      </div>
    );
  }
  return (
    <div className="flex items-start gap-3 rounded-xl border-2 border-red-200 bg-red-50 p-4 animate-[fadeIn_0.3s_ease]">
      <XCircle className="mt-0.5 shrink-0 text-red-600" size={24} />
      <div>
        <p className="font-semibold text-red-800">Unavailable</p>
        <p className="text-sm text-red-700">{result.reason}</p>
      </div>
    </div>
  );
}
