import { Clock } from 'lucide-react';
import { Booking, minutesToLabel } from '@/lib/availability';

export function BookingPill({ b }: { b: Booking }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-md bg-slate-100 px-2 py-1 text-xs text-slate-600">
      <Clock size={12} className="text-slate-400" />
      {minutesToLabel(b.start)}–{minutesToLabel(b.end)}
      <span className="text-slate-400">·</span>
      <span className="italic">{b.bookedBy}</span>
    </span>
  );
}
