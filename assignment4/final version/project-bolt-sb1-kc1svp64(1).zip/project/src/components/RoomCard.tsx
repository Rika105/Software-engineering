import { Building2, Ban, CheckCircle2, Users } from 'lucide-react';
import { EQUIPMENT_LABELS, Room } from '@/lib/availability';

interface RoomCardProps {
  room: Room;
  selected: boolean;
  onSelect: () => void;
}

export function RoomCard({ room, selected, onSelect }: RoomCardProps) {
  return (
    <button
      type="button"
      onClick={onSelect}
      disabled={room.blocked}
      aria-pressed={selected}
      className={[
        'w-full text-left rounded-xl border-2 p-4 transition-all duration-200',
        'focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400',
        room.blocked
          ? 'border-slate-200 bg-slate-50 cursor-not-allowed'
          : selected
            ? 'border-sky-500 bg-sky-50 shadow-md'
            : 'border-slate-200 bg-white hover:border-sky-300 hover:shadow-sm',
      ].join(' ')}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="font-semibold text-slate-800 text-sm leading-snug">
            {room.name}
          </p>
          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
            <span className="inline-flex items-center gap-1">
              <Building2 size={13} /> {room.building}
            </span>
            <span className="inline-flex items-center gap-1">
              <Users size={13} /> {room.capacity} seats
            </span>
          </div>
          <div className="mt-2 flex flex-wrap gap-1">
            {room.equipment.map((item) => (
              <span
                key={item}
                className="rounded-md bg-slate-100 px-1.5 py-0.5 text-[11px] text-slate-600"
              >
                {EQUIPMENT_LABELS[item]}
              </span>
            ))}
          </div>
        </div>
        {room.blocked ? (
          <span className="shrink-0 inline-flex items-center gap-1 rounded-full bg-red-100 px-2 py-0.5 text-[11px] font-medium text-red-700">
            <Ban size={12} /> Blocked
          </span>
        ) : selected ? (
          <CheckCircle2 size={20} className="shrink-0 text-sky-500" />
        ) : null}
      </div>
    </button>
  );
}
