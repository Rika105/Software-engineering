import { describe, expect, it } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import { RequirementFilters } from './RequirementFilters';
import { RoomCard } from './RoomCard';
import { RoomEmptyState } from './RoomEmptyState';
import { SAMPLE_ROOMS } from '@/lib/sampleData';

const noop = () => {};

describe('RoomCard rendering', () => {
  it('F3: renders a blocked room as disabled and marked Blocked', () => {
    const html = renderToStaticMarkup(
      <RoomCard room={SAMPLE_ROOMS[2]} selected={false} onSelect={noop} />
    );
    expect(html).toContain('disabled=""');
    expect(html).toContain('Blocked');
  });

  it('shows capacity and equipment for a bookable room', () => {
    const html = renderToStaticMarkup(
      <RoomCard room={SAMPLE_ROOMS[0]} selected={false} onSelect={noop} />
    );
    expect(html).not.toContain('disabled=""');
    expect(html).toMatch(/120(<!-- -->)? seats/);
    expect(html).toContain('Video conferencing');
    expect(html).toContain('Microphone');
  });
});

describe('RoomEmptyState rendering (F4)', () => {
  it('names the attendee count and required equipment', () => {
    const html = renderToStaticMarkup(
      <RoomEmptyState attendees={5} requiredEquipment={['projector', 'microphone']} />
    );
    expect(html).toContain('No matching rooms');
    expect(html).toContain('No room seats 5 people with projector and microphone.');
  });

  it('asks for an attendee count when none is valid', () => {
    const html = renderToStaticMarkup(<RoomEmptyState attendees={null} requiredEquipment={[]} />);
    expect(html).toContain('Enter the number of attendees');
  });
});

describe('RequirementFilters rendering', () => {
  it('marks only the selected equipment as checked', () => {
    const html = renderToStaticMarkup(
      <RequirementFilters
        attendeesInput="10"
        onAttendeesChange={noop}
        requiredEquipment={['projector']}
        onToggleEquipment={noop}
      />
    );
    expect(html.match(/checked=""/g)).toHaveLength(1);
    expect(html).toContain('Lab computers');
  });
});
