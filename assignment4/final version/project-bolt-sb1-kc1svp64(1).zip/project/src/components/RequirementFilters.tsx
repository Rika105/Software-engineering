import { EQUIPMENT_LABELS, EQUIPMENT_TYPES, Equipment } from '@/lib/availability';

interface RequirementFiltersProps {
  attendeesInput: string;
  onAttendeesChange: (value: string) => void;
  requiredEquipment: Equipment[];
  onToggleEquipment: (item: Equipment) => void;
}

export function RequirementFilters({
  attendeesInput,
  onAttendeesChange,
  requiredEquipment,
  onToggleEquipment,
}: RequirementFiltersProps) {
  return (
    <div className="mb-4 space-y-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <div>
        <label htmlFor="attendees" className="mb-1 block text-xs font-medium text-slate-600">
          Attendees
        </label>
        <input
          id="attendees"
          type="number"
          min={1}
          inputMode="numeric"
          value={attendeesInput}
          onChange={(e) => onAttendeesChange(e.target.value)}
          className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-200 transition-colors"
        />
      </div>
      <fieldset>
        <legend className="mb-2 text-xs font-medium text-slate-600">Required equipment</legend>
        <div className="flex flex-wrap gap-2">
          {EQUIPMENT_TYPES.map((item) => {
            const checked = requiredEquipment.includes(item);
            return (
              <label
                key={item}
                className={[
                  'inline-flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors',
                  checked
                    ? 'border-sky-500 bg-sky-50 text-sky-800'
                    : 'border-slate-300 bg-white text-slate-600 hover:border-sky-300',
                ].join(' ')}
              >
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() => onToggleEquipment(item)}
                  className="h-3.5 w-3.5 accent-sky-500"
                />
                {EQUIPMENT_LABELS[item]}
              </label>
            );
          })}
        </div>
      </fieldset>
    </div>
  );
}
