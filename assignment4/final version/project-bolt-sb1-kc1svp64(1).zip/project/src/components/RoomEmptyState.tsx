import { Search } from 'lucide-react';
import { EQUIPMENT_LABELS, Equipment } from '@/lib/availability';

interface RoomEmptyStateProps {
  attendees: number | null;
  requiredEquipment: Equipment[];
}

export function RoomEmptyState({ attendees, requiredEquipment }: RoomEmptyStateProps) {
  if (attendees === null) {
    return (
      <EmptyCard
        title="Enter the number of attendees"
        message="Add how many people will attend to see rooms that fit."
      />
    );
  }

  const equipmentText = requiredEquipment
    .map((item) => EQUIPMENT_LABELS[item].toLowerCase())
    .join(' and ');
  const people = attendees === 1 ? 'person' : 'people';
  const withEquipment = equipmentText ? ` with ${equipmentText}` : '';

  return (
    <EmptyCard
      title="No matching rooms"
      message={`No room seats ${attendees} ${people}${withEquipment}. Try fewer attendees or remove an equipment requirement.`}
    />
  );
}

function EmptyCard({ title, message }: { title: string; message: string }) {
  return (
    <div className="rounded-xl border-2 border-dashed border-slate-300 bg-white p-6 text-center">
      <Search size={24} className="mx-auto text-slate-400" />
      <p className="mt-2 font-semibold text-slate-700">{title}</p>
      <p className="mt-1 text-sm text-slate-500">{message}</p>
    </div>
  );
}
