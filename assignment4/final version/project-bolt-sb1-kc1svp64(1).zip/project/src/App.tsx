import { useMemo, useState } from 'react';
import { CalendarClock, Clock, DoorClosed, Info } from 'lucide-react';
import { SAMPLE_ROOMS, SAMPLE_BOOKINGS } from '@/lib/sampleData';
import {
  Equipment,
  minutesToLabel,
  labelToMinutes,
  labelToEndMinutes,
  checkAvailability,
  MAX_BOOKING_LENGTH,
  MINUTES_PER_DAY,
} from '@/lib/availability';
import { filterRooms, parseAttendeeCount } from '@/lib/filterRooms';
import { BookingPill } from '@/components/BookingPill';
import { RequirementFilters } from '@/components/RequirementFilters';
import { ResultBanner } from '@/components/ResultBanner';
import { RoomCard } from '@/components/RoomCard';
import { RoomEmptyState } from '@/components/RoomEmptyState';

const TIME_STEP_MINUTES = 15;
const DEFAULT_CURRENT_TIME = 8 * 60 + 30;

function buildTimeOptions(): string[] {
  const opts: string[] = [];
  for (let m = 0; m <= MINUTES_PER_DAY; m += TIME_STEP_MINUTES) {
    if (m === MINUTES_PER_DAY) {
      opts.push('12:00 AM');
    } else {
      opts.push(minutesToLabel(m));
    }
  }
  return opts;
}

const TIME_OPTIONS = buildTimeOptions();
const CURRENT_TIME_OPTIONS = TIME_OPTIONS.slice(0, MINUTES_PER_DAY / TIME_STEP_MINUTES);

export default function App() {
  const [currentTime, setCurrentTime] = useState(DEFAULT_CURRENT_TIME);
  const [attendeesInput, setAttendeesInput] = useState('10');
  const [requiredEquipment, setRequiredEquipment] = useState<Equipment[]>([]);
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>('r2');
  const [startLabel, setStartLabel] = useState('9:30 AM');
  const [endLabel, setEndLabel] = useState('10:30 AM');

  const attendees = parseAttendeeCount(attendeesInput);

  const matchingRooms = useMemo(
    () => filterRooms(SAMPLE_ROOMS, { attendees, requiredEquipment }),
    [attendees, requiredEquipment]
  );

  const selectedRoom = useMemo(
    () => matchingRooms.find((r) => r.id === selectedRoomId) ?? null,
    [matchingRooms, selectedRoomId]
  );

  const roomBookings = useMemo(
    () => (selectedRoom ? SAMPLE_BOOKINGS.filter((b) => b.roomId === selectedRoom.id) : []),
    [selectedRoom]
  );

  const interval = useMemo(
    () => ({
      start: labelToMinutes(startLabel),
      end: labelToEndMinutes(endLabel),
    }),
    [startLabel, endLabel]
  );

  const result = useMemo(
    () => checkAvailability(selectedRoom, interval, currentTime, SAMPLE_BOOKINGS),
    [selectedRoom, interval, currentTime]
  );

  const duration = !isNaN(interval.start) && !isNaN(interval.end)
    ? Math.max(0, interval.end - interval.start)
    : 0;

  const toggleEquipment = (item: Equipment) =>
    setRequiredEquipment((prev) =>
      prev.includes(item) ? prev.filter((e) => e !== item) : [...prev, item]
    );

  const selectEl =
    'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-200 transition-colors';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-5xl px-4 py-5 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-sky-500 text-white">
              <CalendarClock size={22} />
            </div>
            <div>
              <h1 className="text-lg font-bold leading-tight sm:text-xl">
                Smart Campus Room Availability
              </h1>
              <p className="text-xs text-slate-500 sm:text-sm">
                Check whether a room is free for your chosen time slot.
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6 sm:py-8">
        <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
          {/* Left column — requirements and room selection */}
          <section>
            <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold uppercase tracking-wide text-slate-500">
              <DoorClosed size={16} /> Select a Room
            </h2>
            <RequirementFilters
              attendeesInput={attendeesInput}
              onAttendeesChange={setAttendeesInput}
              requiredEquipment={requiredEquipment}
              onToggleEquipment={toggleEquipment}
            />
            {matchingRooms.length === 0 ? (
              <RoomEmptyState attendees={attendees} requiredEquipment={requiredEquipment} />
            ) : (
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
                {matchingRooms.map((room) => (
                  <RoomCard
                    key={room.id}
                    room={room}
                    selected={room.id === selectedRoom?.id}
                    onSelect={() => setSelectedRoomId(room.id)}
                  />
                ))}
              </div>
            )}
          </section>

          {/* Right column — time form + result */}
          <section className="space-y-5">
            {/* Time inputs */}
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold uppercase tracking-wide text-slate-500">
                <Clock size={16} /> Time Slot
              </h2>

              <div className="grid gap-4 sm:grid-cols-3">
                <div>
                  <label htmlFor="current-time" className="mb-1 block text-xs font-medium text-slate-600">
                    Current Time
                  </label>
                  <select
                    id="current-time"
                    className={selectEl}
                    value={minutesToLabel(currentTime)}
                    onChange={(e) => setCurrentTime(labelToMinutes(e.target.value))}
                  >
                    {CURRENT_TIME_OPTIONS.map((label) => (
                      <option key={label} value={label}>{label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="start-time" className="mb-1 block text-xs font-medium text-slate-600">
                    Start
                  </label>
                  <select
                    id="start-time"
                    className={selectEl}
                    value={startLabel}
                    onChange={(e) => setStartLabel(e.target.value)}
                  >
                    {TIME_OPTIONS.map((label) => (
                      <option key={label} value={label}>{label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="end-time" className="mb-1 block text-xs font-medium text-slate-600">
                    End
                  </label>
                  <select
                    id="end-time"
                    className={selectEl}
                    value={endLabel}
                    onChange={(e) => setEndLabel(e.target.value)}
                  >
                    {TIME_OPTIONS.map((label) => (
                      <option key={label} value={label}>{label}</option>
                    ))}
                  </select>
                </div>
              </div>

              {duration > 0 && (
                <p className="mt-3 text-xs text-slate-500">
                  Duration: <span className="font-medium text-slate-700">{duration} min</span>
                  {duration > MAX_BOOKING_LENGTH && (
                    <span className="ml-2 font-medium text-red-600">
                      (exceeds {MAX_BOOKING_LENGTH}-minute limit)
                    </span>
                  )}
                </p>
              )}
            </div>

            {selectedRoom ? (
              <>
                <ResultBanner result={result} />

                {/* Existing bookings for the selected room */}
                <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                  <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <Info size={15} className="text-slate-400" />
                    Existing bookings — {selectedRoom.name.split(' — ')[0]}
                  </h3>
                  {roomBookings.length === 0 ? (
                    <p className="text-sm text-slate-400">No existing bookings for this room.</p>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {roomBookings.map((b, i) => (
                        <BookingPill key={i} b={b} />
                      ))}
                    </div>
                  )}
                </div>
              </>
            ) : (
              <p className="rounded-2xl border border-dashed border-slate-300 bg-white p-5 text-center text-sm text-slate-500">
                Choose a matching room to check its availability.
              </p>
            )}
          </section>
        </div>

        {/* Footer note */}
        <p className="mt-8 text-center text-xs text-slate-400">
          All data is fictional sample data for demonstration purposes.
        </p>
      </main>
    </div>
  );
}
