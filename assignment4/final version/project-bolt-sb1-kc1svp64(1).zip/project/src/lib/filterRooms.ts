import { Equipment, Room } from './availability';

export interface RoomRequirements {
  attendees: number | null;
  requiredEquipment: readonly Equipment[];
}

export function parseAttendeeCount(input: string): number | null {
  if (!/^\d+$/.test(input.trim())) return null;
  const count = Number(input.trim());
  return count >= 1 ? count : null;
}

export function filterRooms(rooms: readonly Room[], requirements: RoomRequirements): Room[] {
  const { attendees, requiredEquipment } = requirements;
  if (attendees === null) return [];
  return rooms.filter(
    (room) =>
      room.capacity >= attendees &&
      requiredEquipment.every((item) => room.equipment.includes(item))
  );
}
