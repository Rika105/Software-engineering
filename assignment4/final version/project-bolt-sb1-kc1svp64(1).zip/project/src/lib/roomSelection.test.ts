import { describe, expect, it } from 'vitest';
import { checkAvailability } from './availability';
import { filterRooms } from './filterRooms';
import { SAMPLE_ROOMS, SAMPLE_BOOKINGS } from './sampleData';

const CURRENT_TIME = 510;
const EN_DASH = '\u2013';

const ids = (rooms: { id: string }[]) => rooms.map((r) => r.id);

describe('room selection with room-specific availability', () => {
  it('F5: the same slot gives different results when switching between matching rooms', () => {
    const [r1, r5] = filterRooms(SAMPLE_ROOMS, {
      attendees: 10,
      requiredEquipment: ['projector', 'microphone'],
    });
    const slot = { start: 600, end: 660 };

    expect(checkAvailability(r1, slot, CURRENT_TIME, SAMPLE_BOOKINGS).available).toBe(true);

    const r5Result = checkAvailability(r5, slot, CURRENT_TIME, SAMPLE_BOOKINGS);
    expect(r5Result.available).toBe(false);
    expect(r5Result.reason).toBe(`Overlaps an existing booking (10:00 AM${EN_DASH}11:00 AM).`);
  });

  it('F5: room-specific bookings belong only to the selected room', () => {
    const bookingsFor = (roomId: string) => SAMPLE_BOOKINGS.filter((b) => b.roomId === roomId);
    expect(bookingsFor('r1')).toHaveLength(2);
    expect(bookingsFor('r5').map((b) => b.bookedBy)).toEqual(['Film Society']);
  });

  it('F3: a blocked room that matches requirements is rejected even when its slot is free', () => {
    const matches = filterRooms(SAMPLE_ROOMS, { attendees: 10, requiredEquipment: ['projector'] });
    expect(ids(matches)).toContain('r3');

    const blocked = matches.find((r) => r.id === 'r3');
    const result = checkAvailability(blocked ?? null, { start: 720, end: 780 }, CURRENT_TIME, SAMPLE_BOOKINGS);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('This room is blocked and cannot be booked.');
  });

  it('F1 and F2 together: capacity and all-equipment requirements both apply', () => {
    const matches = filterRooms(SAMPLE_ROOMS, {
      attendees: 31,
      requiredEquipment: ['lab-computers', 'projector'],
    });
    expect(ids(matches)).toEqual(['r2']);
  });

  it('F4: an empty match list leaves no room to check', () => {
    const matches = filterRooms(SAMPLE_ROOMS, { attendees: 200, requiredEquipment: [] });
    expect(matches).toEqual([]);
    expect(checkAvailability(null, { start: 600, end: 660 }, CURRENT_TIME, SAMPLE_BOOKINGS).available).toBe(false);
  });
});
