import { describe, expect, it } from 'vitest';
import { filterRooms, parseAttendeeCount } from './filterRooms';
import { SAMPLE_ROOMS, SAMPLE_BOOKINGS } from './sampleData';

const ids = (rooms: { id: string }[]) => rooms.map((r) => r.id);

describe('parseAttendeeCount', () => {
  it('accepts positive whole numbers', () => {
    expect(parseAttendeeCount('16')).toBe(16);
    expect(parseAttendeeCount(' 1 ')).toBe(1);
  });

  it('rejects empty, zero, negative, fractional, and non-numeric input', () => {
    expect(parseAttendeeCount('')).toBeNull();
    expect(parseAttendeeCount('0')).toBeNull();
    expect(parseAttendeeCount('-3')).toBeNull();
    expect(parseAttendeeCount('12.5')).toBeNull();
    expect(parseAttendeeCount('abc')).toBeNull();
  });
});

describe('F1: capacity must be at least the attendee count', () => {
  it('keeps a room whose capacity exactly equals the attendee count', () => {
    expect(ids(filterRooms(SAMPLE_ROOMS, { attendees: 15, requiredEquipment: [] }))).toContain('r4');
    expect(ids(filterRooms(SAMPLE_ROOMS, { attendees: 120, requiredEquipment: [] }))).toEqual(['r1']);
  });

  it('drops a room when attendees exceed its capacity by one', () => {
    expect(ids(filterRooms(SAMPLE_ROOMS, { attendees: 16, requiredEquipment: [] }))).not.toContain('r4');
    expect(ids(filterRooms(SAMPLE_ROOMS, { attendees: 121, requiredEquipment: [] }))).toEqual([]);
  });

  it('excludes rooms with insufficient capacity', () => {
    expect(ids(filterRooms(SAMPLE_ROOMS, { attendees: 50, requiredEquipment: [] }))).toEqual(['r1']);
  });
});

describe('F2: every selected equipment item must be present', () => {
  it('returns rooms that contain all selected equipment', () => {
    const matches = filterRooms(SAMPLE_ROOMS, {
      attendees: 10,
      requiredEquipment: ['projector', 'microphone'],
    });
    expect(ids(matches)).toEqual(['r1', 'r5']);
  });

  it('does not match when only some selected equipment is present', () => {
    const matches = filterRooms(SAMPLE_ROOMS, {
      attendees: 10,
      requiredEquipment: ['lab-computers', 'microphone'],
    });
    expect(matches).toEqual([]);
  });

  it('returns every room with capacity when no equipment is required', () => {
    expect(ids(filterRooms(SAMPLE_ROOMS, { attendees: 10, requiredEquipment: [] }))).toEqual([
      'r1',
      'r2',
      'r3',
      'r4',
      'r5',
    ]);
  });
});

describe('F4: no matches returns an empty list', () => {
  it('returns no rooms when attendees exceed every capacity', () => {
    expect(filterRooms(SAMPLE_ROOMS, { attendees: 500, requiredEquipment: [] })).toEqual([]);
  });

  it('returns no rooms when the attendee count is missing', () => {
    expect(filterRooms(SAMPLE_ROOMS, { attendees: null, requiredEquipment: [] })).toEqual([]);
  });
});

describe('data immutability', () => {
  it('does not mutate rooms or the requested equipment list', () => {
    const roomsBefore = JSON.stringify(SAMPLE_ROOMS);
    const requiredEquipment = ['projector' as const];
    filterRooms(SAMPLE_ROOMS, { attendees: 10, requiredEquipment });
    expect(JSON.stringify(SAMPLE_ROOMS)).toBe(roomsBefore);
    expect(requiredEquipment).toEqual(['projector']);
  });

  it('keeps the sample rooms and their bookings at their original values', () => {
    expect(SAMPLE_ROOMS.map((r) => [r.id, r.capacity, r.blocked])).toEqual([
      ['r1', 120, false],
      ['r2', 40, false],
      ['r3', 25, true],
      ['r4', 15, false],
      ['r5', 30, false],
    ]);
    expect(SAMPLE_BOOKINGS.map((b) => [b.roomId, b.start, b.end])).toEqual([
      ['r1', 540, 600],
      ['r1', 840, 930],
      ['r2', 660, 720],
      ['r2', 540, 600],
      ['r4', 780, 840],
      ['r5', 600, 660],
    ]);
  });
});
