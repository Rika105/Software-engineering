# AGENTS.md

## Project

Smart Campus Room Availability Checker. A responsive, single-page application that checks room availability using fictional booking data. No booking creation or persistence.

## Structure

- `src/lib/availability.ts`: pure booking validation logic and time helpers.
- `src/lib/sampleData.ts`: fictional rooms and bookings.
- `src/lib/availability.test.ts`: Vitest regression tests.
- `src/App.tsx`: React UI and feedback.

## Acceptance Criteria

- **AC1:** 0 <= start < end <= 1440 and start > currentTime.
- **AC2:** Maximum duration is 120 minutes.
- **AC3:** Blocked rooms must be rejected.
- **AC4:** Reject real overlaps, allow touching endpoints.
- **AC5:** Do not mutate rooms or booking data.
- **AC6:** Preserve responsive UI and clear feedback.

## Engineering Rules

- Prefer small, focused changes and pure functions.
- Use zero, one, or two design patterns only when justified by real complexity.
- Do not introduce unnecessary Strategy, Adapter, Factory, or Singleton patterns.
- Keep UI behavior and sample data unchanged unless correcting a verified defect.
- Do not add backend, login, database, or booking persistence.
- Never weaken or delete existing tests to make code pass.

## Verification

- Run `npx vitest run`.
- Run `npm run build`.
- Verify desktop and narrow/mobile UI.
- Report changed files, rationale, actual test output, and remaining limitations.
