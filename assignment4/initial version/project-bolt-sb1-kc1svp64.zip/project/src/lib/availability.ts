export interface Booking {
  roomId: string;
  start: number; // minutes from midnight
  end: number; // minutes from midnight
  bookedBy: string;
}

export interface Room {
  id: string;
  name: string;
  building: string;
  capacity: number;
  blocked: boolean;
}

export interface Interval {
  start: number;
  end: number;
}

export interface AvailabilityResult {
  available: boolean;
  reason?: string;
}

export const MINUTES_PER_DAY = 1440;
export const MAX_BOOKING_LENGTH = 120;

export function minutesToLabel(min: number): string {
  const h = Math.floor(min / 60);
  const m = min % 60;
  const period = h >= 12 ? 'PM' : 'AM';
  const displayH = h % 12 === 0 ? 12 : h % 12;
  return `${displayH}:${m.toString().padStart(2, '0')} ${period}`;
}

export function labelToMinutes(label: string): number {
  const match = label.trim().toLowerCase().match(/^(\d{1,2}):(\d{2})\s*(am|pm)$/);
  if (!match) return NaN;
  const h = parseInt(match[1], 10);
  const m = parseInt(match[2], 10);
  const period = match[3];
  if (h < 1 || h > 12 || m < 0 || m > 59) return NaN;
  let hour24 = h % 12;
  if (period === 'pm') hour24 += 12;
  return hour24 * 60 + m;
}

export function labelToEndMinutes(label: string): number {
  if (label.trim().toLowerCase() === '12:00 am') return MINUTES_PER_DAY;
  return labelToMinutes(label);
}

function intervalsOverlap(a: Interval, b: Interval): boolean {
  // Touching endpoints are allowed, so strict inequality
  return a.start < b.end && b.start < a.end;
}

export function checkAvailability(
  room: Room | null,
  interval: Interval,
  currentTime: number,
  bookings: Booking[]
): AvailabilityResult {
  if (!room) {
    return { available: false, reason: 'Please select a room.' };
  }

  // AC3: blocked room — reject regardless of chosen times
   if (room.blocked) {
     return { available: false, reason: 'This room is blocked and cannot be booked.' };
   }

  const { start, end } = interval;

  // AC1: interval validity
  if (isNaN(start) || isNaN(end)) {
    return { available: false, reason: 'Please enter valid start and end times.' };
  }
  if (end <= start) {
    return { available: false, reason: 'End time must be after the start time.' };
  }
  if (!(0 <= start && end <= MINUTES_PER_DAY)) {
    return { available: false, reason: 'Times must be within 12:00 AM–11:59 PM.' };
  }
  if (start <= currentTime) {
    return {
      available: false,
      reason: `Start time must be after the current time (${minutesToLabel(currentTime)}).`,
    };
  }

  // AC2: max 120 minutes
  if (end - start >MAX_BOOKING_LENGTH) {
    return { available: false, reason: 'Bookings cannot be longer than 120 minutes.' };
  }

  // AC4: overlap with existing bookings
  const roomBookings = bookings.filter((b) => b.roomId === room.id);
  for (const b of roomBookings) {
    if (intervalsOverlap({ start, end }, { start: b.start, end: b.end })) {
      return {
        available: false,
        reason: `Overlaps an existing booking (${minutesToLabel(b.start)}–${minutesToLabel(b.end)}).`,
      };
    }
  }

  return { available: true };
}
