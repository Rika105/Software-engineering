import { Room, Booking } from './availability';

export const SAMPLE_ROOMS: Room[] = [
  { id: 'r1', name: 'Room 101 — Lecture Hall', building: 'Engineering Block', capacity: 120, blocked: false },
  { id: 'r2', name: 'Room 204 — CS Lab', building: 'Engineering Block', capacity: 40, blocked: false },
  { id: 'r3', name: 'Room 310 — Seminar Room', building: 'Science Block', capacity: 25, blocked: true },
  { id: 'r4', name: 'Room 505 — Study Lounge', building: 'Library', capacity: 15, blocked: false },
  { id: 'r5', name: 'Room 112 — Media Studio', building: 'Arts Block', capacity: 30, blocked: false },
];

export const SAMPLE_BOOKINGS: Booking[] = [
  { roomId: 'r1', start: 9 * 60, end: 10 * 60, bookedBy: 'Dr. Chen' },
  { roomId: 'r1', start: 14 * 60, end: 15 * 60 + 30, bookedBy: 'Prof. Lee' },
  { roomId: 'r2', start: 11 * 60, end: 12 * 60, bookedBy: 'CS Club' },
  { roomId: 'r2', start: 540, end: 600, bookedBy: 'Study Group A' },
  { roomId: 'r4', start: 13 * 60, end: 14 * 60, bookedBy: 'Book Club' },
  { roomId: 'r5', start: 10 * 60, end: 11 * 60, bookedBy: 'Film Society' },
];
