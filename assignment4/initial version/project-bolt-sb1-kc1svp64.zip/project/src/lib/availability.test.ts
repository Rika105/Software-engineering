import { describe, expect, it } from 'vitest';
import {
  checkAvailability,
  labelToEndMinutes,
  labelToMinutes,
  Room,
  Booking,
  Interval,
} from './availability';
import { SAMPLE_ROOMS, SAMPLE_BOOKINGS } from './sampleData';

const CURRENT_TIME = 540;

function makeRoom(overrides: Partial<Room> = {}): Room {
  return {
    id: 'r1',
    name: 'Room 112',
    building: 'Test',
    capacity: 30,
    blocked: false,
    ...overrides,
  };
}

function makeBookings(overrides?: Booking[]): Booking[] {
  if (overrides !== undefined) return overrides;
  return [{ roomId: 'r1', start: 600, end: 660, bookedBy: 'Test' }];
}

function interval(start: number, end: number): Interval {
  return { start, end };
}

describe('checkAvailability', () => {
  // T01 — 660-720 — true — AC4 (touching endpoint: end of booking 660 == start of request)
  it('T01: 660-720 is available (touches booking end, no overlap)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(660, 720), CURRENT_TIME, bookings);
    expect(result.available).toBe(true);
    expect(result.reason).toBeUndefined();
  });

  // T02 — 540-570 — false — AC1 (start == currentTime, not strictly after)
  it('T02: 540-570 is rejected (start not strictly after currentTime)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(540, 570), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('Start time must be after the current time (9:00 AM).');
  });

  // T03 — 720-720 — false — AC1 (start == end)
  it('T03: 720-720 is rejected (start equals end)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(720, 720), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('End time must be after the start time.');
  });

  // T04 — 750-720 — false — AC1 (end < start)
  it('T04: 750-720 is rejected (end before start)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(750, 720), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('End time must be after the start time.');
  });

  // T05 — 1380-1441 — false — AC1 (end exceeds 1440)
  it('T05: 1380-1441 is rejected (end exceeds 1440)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(1380, 1441), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('Times must be within 12:00 AM\u201311:59 PM.');
  });

  // T06 — 720-840 — true — AC2 (exactly 120 minutes, at the limit)
  it('T06: 720-840 is available (exactly 120 minutes)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(720, 840), CURRENT_TIME, bookings);
    expect(result.available).toBe(true);
    expect(result.reason).toBeUndefined();
  });

  // T07 — 720-841 — false — AC2 (121 minutes, exceeds limit)
  it('T07: 720-841 is rejected (exceeds 120-minute limit)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(720, 841), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('Bookings cannot be longer than 120 minutes.');
  });

  // T08 — 570-600 — true — AC4 (touches booking start, no overlap)
  it('T08: 570-600 is available (touches booking start, no overlap)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(570, 600), CURRENT_TIME, bookings);
    expect(result.available).toBe(true);
    expect(result.reason).toBeUndefined();
  });

  // T09 — 630-690 — false — AC4 (overlaps booking 600-660)
  it('T09: 630-690 is rejected (overlaps existing booking)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(630, 690), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('Overlaps an existing booking (10:00 AM\u201311:00 AM).');
  });

  // T10 — 570-690 — false — AC4 (contains booking 600-660)
  it('T10: 570-690 is rejected (contains existing booking)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(570, 690), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('Overlaps an existing booking (10:00 AM\u201311:00 AM).');
  });

  // T11 — 615-645 — false — AC4 (inside booking 600-660)
  it('T11: 615-645 is rejected (inside existing booking)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(615, 645), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('Overlaps an existing booking (10:00 AM\u201311:00 AM).');
  });

  // T12 — 600-660 — false — AC4 (exact match with booking)
  it('T12: 600-660 is rejected (exact match with existing booking)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(600, 660), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('Overlaps an existing booking (10:00 AM\u201311:00 AM).');
  });

  // T13 — 660-720 with blocked room — false — AC3
  it('T13: 660-720 with blocked room is rejected', () => {
    const room = makeRoom({ blocked: true });
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(660, 720), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('This room is blocked and cannot be booked.');
  });

  // T14 — 630-690 with no bookings — true — AC4
  it('T14: 630-690 with empty bookings is available', () => {
    const room = makeRoom();
    const bookings = makeBookings([]);
    const result = checkAvailability(room, interval(630, 690), CURRENT_TIME, bookings);
    expect(result.available).toBe(true);
    expect(result.reason).toBeUndefined();
  });

  // T15 — booking data unchanged after several calls — AC5
  it('T15: room and bookings are unchanged after several calls', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const roomBefore = JSON.stringify(room);
    const bookingsBefore = JSON.stringify(bookings);
    checkAvailability(room, interval(630, 690), CURRENT_TIME, bookings); // rejected by overlap
    checkAvailability(room, interval(660, 720), CURRENT_TIME, bookings); // available
    checkAvailability(makeRoom({ blocked: true }), interval(660, 720), CURRENT_TIME, bookings); // blocked
    checkAvailability(room, interval(750, 720), CURRENT_TIME, bookings); // invalid interval
    expect(JSON.stringify(room)).toBe(roomBefore);
    expect(JSON.stringify(bookings)).toBe(bookingsBefore);
  });

  // T16 — 630-690 when the only booking belongs to roomId 'r2' — true — AC4
  it('T16: 630-690 is available when booking belongs to a different room', () => {
    const room = makeRoom();
    const bookings: Booking[] = [{ roomId: 'r2', start: 600, end: 660, bookedBy: 'Test' }];
    const result = checkAvailability(room, interval(630, 690), CURRENT_TIME, bookings);
    expect(result.available).toBe(true);
    expect(result.reason).toBeUndefined();
  });

  // T17 — 541-600 — true — AC1 (start is strictly after currentTime by 1 minute)
  it('T17: 541-600 is available (start strictly after currentTime)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(541, 600), CURRENT_TIME, bookings);
    expect(result.available).toBe(true);
    expect(result.reason).toBeUndefined();
  });

  // T18 — -30-30 — false — AC1 (start below 0, lower bound check)
  it('T18: -30-30 is rejected (start below 0)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(-30, 30), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('Times must be within 12:00 AM\u201311:59 PM.');
  });

  // T19 — blocked room with invalid interval (750-720) — false — AC3 (checked before interval validity)
  it('T19: blocked room with invalid interval is rejected as blocked (AC3 checked first)', () => {
    const room = makeRoom({ blocked: true });
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(750, 720), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('This room is blocked and cannot be booked.');
  });

  // T20 — NaN start (NaN, 720) — false — AC1 (invalid start/end)
  it('T20: NaN start is rejected (invalid start and end times)', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const result = checkAvailability(room, interval(NaN, 720), CURRENT_TIME, bookings);
    expect(result.available).toBe(false);
    expect(result.reason).toBe('Please enter valid start and end times.');
  });
});

describe('midnight time handling', () => {
  it('labelToMinutes maps 12:00 AM to start of day (0)', () => {
    expect(labelToMinutes('12:00 AM')).toBe(0);
  });

  it('labelToEndMinutes maps 12:00 AM to end of day (1440)', () => {
    expect(labelToEndMinutes('12:00 AM')).toBe(1440);
  });

  it('labelToEndMinutes parses ordinary labels like labelToMinutes', () => {
    expect(labelToEndMinutes('11:30 PM')).toBe(labelToMinutes('11:30 PM'));
    expect(labelToEndMinutes('10:30 AM')).toBe(630);
  });

  it('11:30 PM to 12:00 AM is available when the end is parsed as an endpoint', () => {
    const room = makeRoom();
    const bookings = makeBookings();
    const slot: Interval = {
      start: labelToMinutes('11:30 PM'),
      end: labelToEndMinutes('12:00 AM'),
    };
    const result = checkAvailability(room, slot, CURRENT_TIME, bookings);
    expect(result.available).toBe(true);
    expect(result.reason).toBeUndefined();
  });
});

describe('booking data stays unchanged', () => {
  it('sample rooms and bookings are not mutated by availability checks', () => {
    const roomsBefore = JSON.stringify(SAMPLE_ROOMS);
    const bookingsBefore = JSON.stringify(SAMPLE_BOOKINGS);
    for (const room of SAMPLE_ROOMS) {
      checkAvailability(room, interval(660, 720), CURRENT_TIME, SAMPLE_BOOKINGS);
      checkAvailability(room, interval(630, 690), CURRENT_TIME, SAMPLE_BOOKINGS);
    }
    expect(JSON.stringify(SAMPLE_ROOMS)).toBe(roomsBefore);
    expect(JSON.stringify(SAMPLE_BOOKINGS)).toBe(bookingsBefore);
  });
});
