import { useMemo, useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  Clock,
  DoorClosed,
  Users,
  Building2,
  Ban,
  CalendarClock,
  Info,
} from 'lucide-react';
import {
  SAMPLE_ROOMS,
  SAMPLE_BOOKINGS,
} from '@/lib/sampleData';
import {
  Room,
  Booking,
  AvailabilityResult,
  minutesToLabel,
  labelToMinutes,
  labelToEndMinutes,
  checkAvailability,
  MAX_BOOKING_LENGTH,
  MINUTES_PER_DAY,
} from '@/lib/availability';

const TIME_STEP_MINUTES = 15;
const DEFAULT_CURRENT_TIME = 8 * 60 + 30;

function buildTimeOptions(): string[] {
  const opts: string[] = [];
  for (let m = 0; m <= MINUTES_PER_DAY; m += TIME_STEP_MINUTES) {
    if (m === MINUTES_PER_DAY) {
      opts.push('12:00 AM');
    } else {
      opts.push(minutesToLabel(m));
    }
  }
  return opts;
}

const TIME_OPTIONS = buildTimeOptions();
const CURRENT_TIME_OPTIONS = TIME_OPTIONS.slice(0, MINUTES_PER_DAY / TIME_STEP_MINUTES);

function RoomCard({
  room,
  selected,
  onSelect,
}: {
  room: Room;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={[
        'w-full text-left rounded-xl border-2 p-4 transition-all duration-200',
        'focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400',
        room.blocked
          ? selected
            ? 'border-red-400 bg-red-50 shadow-md'
            : 'border-slate-200 bg-slate-50 hover:border-red-300 hover:shadow-sm'
          : selected
            ? 'border-sky-500 bg-sky-50 shadow-md'
            : 'border-slate-200 bg-white hover:border-sky-300 hover:shadow-sm',
      ].join(' ')}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="font-semibold text-slate-800 text-sm leading-snug">
            {room.name}
          </p>
          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
            <span className="inline-flex items-center gap-1">
              <Building2 size={13} /> {room.building}
            </span>
            <span className="inline-flex items-center gap-1">
              <Users size={13} /> {room.capacity} seats
            </span>
          </div>
        </div>
        {room.blocked ? (
          <span className="shrink-0 inline-flex items-center gap-1 rounded-full bg-red-100 px-2 py-0.5 text-[11px] font-medium text-red-700">
            <Ban size={12} /> Blocked
          </span>
        ) : selected ? (
          <CheckCircle2 size={20} className="shrink-0 text-sky-500" />
        ) : null}
      </div>
    </button>
  );
}

function BookingPill({ b }: { b: Booking }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-md bg-slate-100 px-2 py-1 text-xs text-slate-600">
      <Clock size={12} className="text-slate-400" />
      {minutesToLabel(b.start)}–{minutesToLabel(b.end)}
      <span className="text-slate-400">·</span>
      <span className="italic">{b.bookedBy}</span>
    </span>
  );
}

function ResultBanner({ result }: { result: AvailabilityResult }) {
  if (result.available) {
    return (
      <div className="flex items-start gap-3 rounded-xl border-2 border-emerald-200 bg-emerald-50 p-4 animate-[fadeIn_0.3s_ease]">
        <CheckCircle2 className="mt-0.5 shrink-0 text-emerald-600" size={24} />
        <div>
          <p className="font-semibold text-emerald-800">Available</p>
          <p className="text-sm text-emerald-700">
            This time slot is open. You can proceed with the booking.
          </p>
        </div>
      </div>
    );
  }
  return (
    <div className="flex items-start gap-3 rounded-xl border-2 border-red-200 bg-red-50 p-4 animate-[fadeIn_0.3s_ease]">
      <XCircle className="mt-0.5 shrink-0 text-red-600" size={24} />
      <div>
        <p className="font-semibold text-red-800">Unavailable</p>
        <p className="text-sm text-red-700">{result.reason}</p>
      </div>
    </div>
  );
}

export default function App() {
  const [currentTime, setCurrentTime] = useState(DEFAULT_CURRENT_TIME);
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>('r2');
  const [startLabel, setStartLabel] = useState('9:30 AM');
  const [endLabel, setEndLabel] = useState('10:30 AM');

  const selectedRoom = useMemo(
    () => SAMPLE_ROOMS.find((r) => r.id === selectedRoomId) ?? null,
    [selectedRoomId]
  );

  const roomBookings = useMemo(
    () => SAMPLE_BOOKINGS.filter((b) => b.roomId === selectedRoomId),
    [selectedRoomId]
  );

  const interval = useMemo(
    () => ({
      start: labelToMinutes(startLabel),
      end: labelToEndMinutes(endLabel),
    }),
    [startLabel, endLabel]
  );

  const result = useMemo(
    () =>
      checkAvailability(
        selectedRoom,
        interval,
        currentTime,
        SAMPLE_BOOKINGS
      ),
    [selectedRoom, interval, currentTime]
  );

  const duration = !isNaN(interval.start) && !isNaN(interval.end)
    ? Math.max(0, interval.end - interval.start)
    : 0;

  const selectEl =
    'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-200 transition-colors';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-5xl px-4 py-5 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-sky-500 text-white">
              <CalendarClock size={22} />
            </div>
            <div>
              <h1 className="text-lg font-bold leading-tight sm:text-xl">
                Smart Campus Room Availability
              </h1>
              <p className="text-xs text-slate-500 sm:text-sm">
                Check whether a room is free for your chosen time slot.
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6 sm:py-8">
        <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
          {/* Left column — room selection */}
          <section>
            <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold uppercase tracking-wide text-slate-500">
              <DoorClosed size={16} /> Select a Room
            </h2>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
              {SAMPLE_ROOMS.map((room) => (
                <RoomCard
                  key={room.id}
                  room={room}
                  selected={room.id === selectedRoomId}
                  onSelect={() => setSelectedRoomId(room.id)}
                />
              ))}
            </div>
          </section>

          {/* Right column — time form + result */}
          <section className="space-y-5">
            {/* Time inputs */}
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold uppercase tracking-wide text-slate-500">
                <Clock size={16} /> Time Slot
              </h2>

              <div className="grid gap-4 sm:grid-cols-3">
                <div>
                  <label htmlFor="current-time" className="mb-1 block text-xs font-medium text-slate-600">
                    Current Time
                  </label>
                  <select
                    id="current-time"
                    className={selectEl}
                    value={minutesToLabel(currentTime)}
                    onChange={(e) => setCurrentTime(labelToMinutes(e.target.value))}
                  >
                    {CURRENT_TIME_OPTIONS.map((label) => (
                      <option key={label} value={label}>{label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="start-time" className="mb-1 block text-xs font-medium text-slate-600">
                    Start
                  </label>
                  <select
                    id="start-time"
                    className={selectEl}
                    value={startLabel}
                    onChange={(e) => setStartLabel(e.target.value)}
                  >
                    {TIME_OPTIONS.map((label) => (
                      <option key={label} value={label}>{label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="end-time" className="mb-1 block text-xs font-medium text-slate-600">
                    End
                  </label>
                  <select
                    id="end-time"
                    className={selectEl}
                    value={endLabel}
                    onChange={(e) => setEndLabel(e.target.value)}
                  >
                    {TIME_OPTIONS.map((label) => (
                      <option key={label} value={label}>{label}</option>
                    ))}
                  </select>
                </div>
              </div>

              {duration > 0 && (
                <p className="mt-3 text-xs text-slate-500">
                  Duration: <span className="font-medium text-slate-700">{duration} min</span>
                  {duration > MAX_BOOKING_LENGTH && (
                    <span className="ml-2 font-medium text-red-600">
                      (exceeds {MAX_BOOKING_LENGTH}-minute limit)
                    </span>
                  )}
                </p>
              )}
            </div>

            {/* Result */}
            <ResultBanner result={result} />

            {/* Existing bookings for the selected room */}
            {selectedRoom && (
              <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-700">
                  <Info size={15} className="text-slate-400" />
                  Existing bookings — {selectedRoom.name.split(' — ')[0]}
                </h3>
                {roomBookings.length === 0 ? (
                  <p className="text-sm text-slate-400">No existing bookings for this room.</p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {roomBookings.map((b, i) => (
                      <BookingPill key={i} b={b} />
                    ))}
                  </div>
                )}
                {selectedRoom.blocked && (
                  <p className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-700">
                    <Ban size={14} /> This room is blocked and cannot be booked.
                  </p>
                )}
              </div>
            )}
          </section>
        </div>

        {/* Footer note */}
        <p className="mt-8 text-center text-xs text-slate-400">
          All data is fictional sample data for demonstration purposes.
        </p>
      </main>
    </div>
  );
}
